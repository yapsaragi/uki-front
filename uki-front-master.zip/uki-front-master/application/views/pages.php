    <!--./ Social Div End -->
   <div class="general-subhead">
       <h1><?php echo $data[0] -> ptitle; ?></h1>
   </div>
     <!--./ Gereral Subhead End -->
    
    <section id="port-folio">
        <div class="container">
            <div class="row">
                <?php echo $data[0] -> pcontent; ?>
                <?php echo $plugins; ?>
            </div>
           </div>
    </section>
    <!--./ Request Quote End -->
  