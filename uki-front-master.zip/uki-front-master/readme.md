# UKI FRONTEND

[INSTALLATION](#installation) |
[CONFIGURATION](#configuration) |
[LICENSE](#license)


### CONFIGURATION
------------

* copy file .env.sample become .env
* Setting .env file as your system


### INSTALLATION
------------

* install php composer at https://getcomposer.org/download/
* run composer install


### LICENSE
----

[Beerware](https://en.wikipedia.org/wiki/Beerware "Beerware") © [Arpac.Co.Id]